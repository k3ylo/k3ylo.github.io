"gamemenu"
{
"1"
{
"label" "continue"
"command" "resumegame"
"onlyingame" "1"
}
"2"
{
"label" "disconnect"
"command" "disconnect"
"onlyingame" "1"
}
"3"
{
"label" "player list"
"command" "openplayerlistdialog"
"onlyingame" "1"
}
"4"
{
"label" "servers"
"command" "openserverbrowser"
}
"5"
{
"label" "create server"
"command" "opencreatemultiplayergamedialog"
}
"6"

{
"label" "settings"
"command" "openoptionsdialog"
}
"7"
{
"label" "quit"
"command" "quit"
}
}