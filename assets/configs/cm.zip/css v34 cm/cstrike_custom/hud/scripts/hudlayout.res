"resource/hudlayout.res"
{
"speedometer"
{
"visible" "1"
"enabled" "1"
"controlname" "imagepanel"
"fieldname" "speedometer"
"zpos" "2"
"xpos" "c-41"
"ypos" "398"
"wide" "81"
"tall" "20"
"image" "replay/thumbnails/numbers"
"scaleimage" "1"
}
"speedometer2"
{
"visible" "1"
"enabled" "1"
"controlname" "imagepanel"
"fieldname" "speedometer2"
"zpos" "0"
"xpos" "c-42"
"ypos" "399"
"wide" "85"
"tall" "20"
"image" "replay/thumbnails/numbersbg"
"scaleimage" "1"
}
hudhealth
{
"fieldname" "hudhealth"
"xpos" "c-35"
"ypos" "r62"
"wide" "132"
"tall"  "40"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"icon_xpos" "0"
"icon_ypos" "0"
"digit_xpos" "18"
"digit_ypos" "1"
"lowhealthcolor"           "255 255 255 255"
}
hudcommentary
{
"fieldname" "hudcommentary"
"xpos" "c-190"
"ypos" "350"
"wide" "380"
"tall"  "40"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"bar_xpos" "50"
"bar_ypos" "20"
"bar_height" "8"
"bar_width" "320"
"speaker_xpos" "50"
"speaker_ypos" "8"
"count_xpos_from_right" "10"// counts from the right side
"count_ypos" "8"
"icon_texture" "vgui/hud/icon_commentary"
"icon_xpos" "0"
"icon_ypos" "0"
"icon_width" "40"
"icon_height" "40"
}
hudhdrdemo
{
"fieldname" "hudhdrdemo"
"xpos" "0"
"ypos" "0"
"wide" "640"
"tall"  "480"
"visible" "0"
"enabled" "1"
"alpha" "255"
"paintbackgroundtype" "2"
"bordercolor" "0 0 0 255"
"borderleft" "16"
"borderright" "16"
"bordertop" "16"
"borderbottom" "64"
"bordercenter" "0"
"textcolor" "255 255 255 255"
"lefttitley" "422"
"righttitley" "422"
}
targetid
{
"fieldname" "targetid"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudarmor
{
"fieldname" "hudarmor"
"xpos" "c-35"
"ypos" "r43"
"wide" "132"
"tall"  "30"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"icon_xpos" "0"
"icon_ypos" "0"
"digit_xpos" "34"
"digit_ypos" "0"
}
hudsuit
{
"fieldname" "hudsuit"
"xpos" "140"
"ypos" "432"
"wide" "108"
"tall"  "36"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"text_xpos" "8"
"text_ypos" "20"
"digit_xpos" "50"
"digit_ypos" "2"
}
hudprogressbar
{
"fieldname" "hudprogressbar"
"xpos" "c-114"
"ypos"           "300"
"wide"           "300"
"tall"           "15"
"visible"           "1"
"enabled"           "1"
"borderthickness" "1"
"paintbackgroundtype" "2"
}
hudroundtimer
{
"fieldname" "hudroundtimer"
"xpos" "c-35"
"ypos" "r52"
"wide" "120"
"tall"  "40"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"icon_xpos" "0"
"icon_ypos" "0"
"digit_xpos" "26"
"digit_ypos" "1"
}
hudaccount
{
"fieldname" "hudaccount"
"xpos" "c-35"
"ypos" "r36"
"wide" "116"
"tall"  "40"
"visible" "1"
"enabled" "1" 
"paintbackgroundtype" "2" 
"icon_xpos" "0"
"icon_ypos" "2"
"digit_xpos" "73"
"digit_ypos" "2"
}
hudshoppingcart
{
"fieldname" "hudshoppingcart"
"xpos"           "c-250"
"ypos"           "r27"
"wide" "40"
"tall"  "40"
"visible"           "1"
"enabled"           "1"
"paintbackgroundtype" "2"
"iconcolor"           "255 255 255 255"
}
hudc4
{
"fieldname" "hudc4"
"xpos" "c32"
"ypos" "r43"
"wide" "40"
"tall"  "40"
"visible"           "1"
"enabled"           "1"
"paintbackgroundtype" "1"
"iconcolor"           "255 255 255 255"
"flashcolor"           "0 0 0 0"
}
huddefuser
{
"fieldname" "huddefuser"
"xpos" "c32"
"ypos" "r43"
"wide" "40"
"tall"  "40"
"visible"           "1"
"enabled"           "1"
"paintbackgroundtype" "2"
"iconcolor"           "255 255 255 255"
}
hudhostagerescuezone
{
"fieldname" "hudhostagerescuezone"
"xpos" "16"
"ypos" "240"
"wide" "40"
"tall"  "40"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"iconcolor" "hudicon_green"
"flashcolor" "hudicon_red"
}
hudscenarioicon 
{
"fieldname" "hudscenarioicon"
"xpos"           "c+110"
"ypos"           "443"
"wide" "40"
"tall"  "44"
"visible"           "1"
"enabled"           "1"
"paintbackgroundtype" "2"
"iconcolor"           "240 255 249 225"
}
hudammo
{
"fieldname" "hudammo"
"xpos" "c-35"
"ypos" "r35"
"wide" "170"
"tall"  "40"
"visible" "1"
"enabled" "1"
"paintbackgroundtype" "2"
"digit_xpos" "26"
"digit_ypos" "11"
"digit2_xpos" "46"
"digit2_ypos" "11"
"bar_xpos" "44"
"bar_ypos" "33"
"bar_height" "2"
"bar_width" "2"
"icon_xpos" "-3"
"icon_ypos" "5"
}
hudflashlight
{
"fieldname" "hudflashlight"
"visible" "1"
"enabled" "1"
"xpos" "16"
"ypos" "370"
"wide" "102"
"tall" "20"
"text_xpos" "8"
"text_ypos" "6"
"textcolor" "255 170 0 220"
"paintbackgroundtype" "2"
}
huddamageindicator
{
"fieldname" "huddamageindicator"
"visible" "1"
"enabled" "1"
"dmgcolorleft" "255 0 0 0"
"dmgcolorright" "255 0 0 0"
"dmg_xpos" "30"
"dmg_ypos" "100"
"dmg_wide" "36"
"dmg_tall1" "240"
"dmg_tall2" "200"
}
hudzoom
{
"fieldname" "hudzoom"
"visible" "1"
"enabled" "1"
"circle1radius" "66"
"circle2radius" "74"
"dashgap" "16"
"dashheight" "4"
"borderthickness" "88"
}
hudweaponselection
{
"fieldname" "hudweaponselection"
"xpos" "r640"
"wide" "640"
"ypos"           "15"
"visible"           "1"
"enabled"           "1"
"smallboxsize"           "10" // def 60
"largeboxwide"           "130" // def 108
"largeboxtall"           "30" // def 80
"boxgap"           "5" //def 8
"selectionnumberxpos"           "999"
"selectionnumberypos"           "999"
"selectiongrowtime" "0" // def 0.4
"iconxpos"           "27" //def 8
"iconypos"           "-20" //def 0
"textypos"           "999" // def 68
"textcolor" "white"
"maxslots"           "4"
"playselectsounds" "1"
}
hudcrosshair
{
"fieldname" "hudcrosshair"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
huddeathnotice
{
"fieldname" "huddeathnotice"
"visible"           "1"
"enabled"           "1"
"xpos"           "r640"
"ypos"           "12"
"wide" "628"
"tall" "468"
"maxdeathnotices"           "5"
"lineheight"           "22"
"rightjustify"  "1"// if 1, draw notices from the right
"textfont" "default"
"cttextcolor"           "153 204 255 255"
"terroristtextcolor"           "255 64 64 255"
}
hudvehicle
{
"fieldname" "hudvehicle"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
cvprofpanel
{
"fieldname" "cvprofpanel"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
scorepanel
{
"fieldname" "scorepanel"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudtrain
{
"fieldname" "hudtrain"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudmotd
{
"fieldname" "hudmotd"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudmessage
{
"fieldname" "hudmessage"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudmenu
{
"fieldname" "hudmenu"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
"zpos" "1"
"textfont" "default"
"itemfont" "default"
"itemfontpulsing" "default"
}
hudclosecaption
{
"fieldname" "hudclosecaption"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudhistoryresource 
{
"fieldname" "hudhistoryresource"
"visible" "1"
"enabled" "1"
"xpos" "r640"
"wide" "640"
"tall" "330"
"history_gap" "55"
}
hudgeiger
{
"fieldname" "hudgeiger"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudquickinfo
{
"fieldname" "hudquickinfo"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudweapon
{
"fieldname" "hudweapon"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudanimationinfo
{
"fieldname" "hudanimationinfo"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
cbudgetpanel
{
"fieldname" "cbudgetpanel"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
ctexturebudgetpanel
{
"fieldname" "ctexturebudgetpanel"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudpredictiondump
{
"fieldname" "hudpredictiondump"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudradar
{
"fieldname" "hudradar"
"visible"           "1"
"enabled"           "1"
"xpos"           "16"
"ypos"           "30"
"wide"           "96"
"tall"           "96"
}
hudlocation
{
"fieldname" "hudlocation"
"visible"           "1"
"enabled"           "1"
"xpos"           "64"
"ypos"           "10"
"wide"           "96"
"tall"           "16"
"textalignment" "south"
}
hudscope
{
"fieldname" "hudzoom"
"visible" "1"
"enabled" "1"
"wide" "640"
"tall" "480"
}
hudvoiceselfstatus
{
"fieldname" "hudvoiceselfstatus"
"visible"           "1"
"enabled"           "1"
"xpos"           "r34"
"ypos"           "355"
"wide" "24"
"tall" "24"
}
hudvoicestatus
{
"fieldname" "hudvoicestatus"
"visible" "1"
"enabled" "1"
"xpos" "r200"
"ypos" "0"
"wide" "200"
"tall" "400"
"item_tall" "16"
"item_wide" "195"
"item_spacing" "2"
"show_avatar" "1"
"show_friend" "1"
"show_voice_icon" "0"
"show_dead_icon" "1"
"dead_xpos" "0"
"dead_ypos" "0"
"dead_wide" "16"
"dead_tall" "16"
"avatar_xpos" "14"
"avatar_ypos" "0"
"avatar_wide" "16"
"avatar_tall" "16"
"text_xpos" "42"
"fade_in_time" "0.07"
"fade_out_time" "1.0"
}
hudflashbang
{
}
hudhintdisplay
{
"fieldname" "hudhintdisplay"
"visible"           "1"
"enabled"           "1"
"xpos"           "c-240"
"ypos"           "300"
"wide" "480"
"tall" "100"
"text_xpos" "8"
"text_ypos" "8"
"center_x" "0"// center text horizontally
"center_y" "-1"// align text on the bottom
"hintsize" "1"
}
hudhintkeydisplay
{
"fieldname" "hudhintkeydisplay"
"visible" "0"
"enabled" "1"
"xpos" "r120"
"ypos" "r340"
"wide" "100"
"tall" "200"
"text_xpos" "8"
"text_ypos" "8"
"text_xgap" "8"
"text_ygap" "8"
"textcolor" "255 170 0 220"
"paintbackgroundtype" "2"
}
hudterritory
{
"fieldname" "hudterritory"
"visible" "1"
"enabled" "1"
"xpos" "240"
"ypos" "432"
"wide" "240"
"tall" "48"
}
territoryscore
{
    "fieldname" "territoryscore"
    "visible" "0"
    "enabled" "0"
    "xpos" "240"
    "ypos" "450"
    "wide" "200"
    "tall" "200"
    "text_xpos" "8"
    "text_ypos" "4"
}
"hudchat"
{
"controlname" "editablepanel"
"fieldname" "hudchat"
"visible" "1"
"enabled" "1"
"xpos" "10"[$win32]
"xpos" "42"[$x360]
"ypos" "275"
"wide" "320"
"tall" "120"
"paintbackgroundtype" "2"
}
winpanel_round
{
"fieldname" "winpanel_round"
"visible" "1"
"enabled" "1"
"xpos" "c-110"
"ypos" "287"
"zpos" "0"
"wide" "220"
"tall" "138"
"paintbackgroundtype" "2"
}
winpanel_match
{
"fieldname" "winpanel_match"
"visible" "1"
"enabled" "1"
"xpos" "c-35"
"ypos" "c-175"
"wide" "300"
"tall" "350"
"paintbackgroundtype" "2"
}
freezepanel
{
"fieldname" "freezepanel"
"visible" "1"
"enabled" "1"
"xpos" "0"
"ypos" "0"
"wide" "f0"
"tall" "480"
}
freezepanelcallout
{
"fieldname" "freezepanelcallout"
"visible" "1"
"enabled" "1"
"xpos" "200"
"ypos" "200"
"wide" "100"
"tall" "50"
}
achievementannouncepanel
{
"fieldname" "achievementannouncepanel"
"visible" "1"
"enabled" "1"
"xpos" "0"
"ypos" "0"
"wide" "f0"
"tall" "480"
}
statpanel
{
"fieldname" "statpanel"
"visible" "0"
"enabled" "1"
}
achievementnotificationpanel
{
"fieldname" "achievementnotificationpanel"
"visible" "1"
"enabled" "1"
}
hudautoaim
{
"fieldname" "hudautoaim"
"visible" "0"
"enabled" "1"
}
"hudachievementtracker"
{
"controlname" "editablepanel"
"fieldname" "hudachievementtracker"
"xpos" "10"
"normaly" "245"
"engineery" "170"
"zpos" "20"
"wide" "250"
"tall" "280"
"visible" "1"
"enabled" "1"
}
}