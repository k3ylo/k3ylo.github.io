"gamemenu"
{
	"1"
	{
		"label" "resume game"
		"command" "resumegame"
		"ingameorder" "10"
		"onlyingame" "1"
	}
	"2"
	{
		"label" "disconnect"
		"command" "disconnect"
		"onlyingame" "1"
		"ingameorder" "10"
	}

	"5"	
	{
		"label" "new game"
		"command" "opennewgamedialog"
		"ingameorder" "40"
		"notmulti" "1"
	}
	"6"
	{
		"label" "load"
		"command" "openloadgamedialog"
		"ingameorder" "30"
		"notmulti" "1"
	}
	"7"
	{
		"label" "save"
		"command" "opensavegamedialog"
		"ingameorder" "20"
		"notmulti" "1"
		"onlyingame" "1"
	}
	"7_5"
	{
		"label" "#gameui_gamemenu_activatevr"
		"command" "engine vr_activate"
		"ingameorder" "40"
		"onlywhenvrenabled" "1"
		"onlywhenvrinactive" "1"
	}
	"7_6"
	{
		"label" "#gameui_gamemenu_deactivatevr"
		"command" "engine vr_deactivate"
		"ingameorder" "40"
		"onlywhenvrenabled" "1"
		"onlywhenvractive" "1"
	}
	"9"
	{
		"label" "#gameui_controller"
		"command" "opencontrollerdialog"
		"ingameorder" "60"
		"consoleonly" "1"
	}
	"10"
	{
		"label" "options"
		"command" "openoptionsdialog"
		"ingameorder" "70"
	}
	"11"
	{
		"label" "quit"
		"command" "quit"
		"ingameorder" "80"
	}
}

